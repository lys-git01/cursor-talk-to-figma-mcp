// 7.4.7.메뉴관리	A0040	menuMgmt	BM-7407

import React from "react";
import { Card } from "primereact/card";

const MenuMgmtPage = () => {
  return (
    <div className="p-4">
      <Card title="메뉴 관리" className="shadow-1">
        <div className="p-fluid">{/* 여기에 메뉴 관리 컨텐츠가 들어갈 예정입니다 */}</div>
      </Card>
    </div>
  );
};

export default MenuMgmtPage;
