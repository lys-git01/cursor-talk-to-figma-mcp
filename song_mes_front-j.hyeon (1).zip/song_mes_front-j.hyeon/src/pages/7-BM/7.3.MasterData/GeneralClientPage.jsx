import React from "react";

const GeneralClientPage = () => {
  return <div>GeneralClientPage</div>;
};

export default GeneralClientPage;
