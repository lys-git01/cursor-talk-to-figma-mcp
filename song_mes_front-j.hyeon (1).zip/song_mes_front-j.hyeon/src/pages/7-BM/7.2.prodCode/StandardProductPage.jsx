import React from "react";

const StandardProductPage = () => {
  return <div>StandardProductPage</div>;
};

export default StandardProductPage;
