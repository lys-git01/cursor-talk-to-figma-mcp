import React from "react";

const WorkTypeEntryPage = () => {
  return <div>WorkTypeEntryPage</div>;
};

export default WorkTypeEntryPage;
